package com.patrones.u2;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Supplier;

public class NotifierFactory {

    private static final Map<String, Supplier<Notifier>> registro = new HashMap<>();

    static {
        registro.put("email", EmailNotifier::new);
        registro.put("sms", SmsNotifier::new);
        registro.put("push", PushNotifier::new);
    }

    // Permite agregar nuevos tipos SIN modificar la clase (OCP)
    public static void registrar(String tipo, Supplier<Notifier> factory) {
        registro.put(tipo.toLowerCase(), factory);
    }

    public static Notifier crear(String tipo) {
        Supplier<Notifier> factory = registro.get(tipo.toLowerCase());

        if (factory == null) {
            throw new IllegalArgumentException("Tipo no válido: " + tipo);
        }

        return factory.get();
    }
}
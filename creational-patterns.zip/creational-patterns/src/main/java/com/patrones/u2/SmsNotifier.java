package com.patrones.u2;

public class SmsNotifier implements Notifier {

    public String channel() {
        return "SMS";
    }

    public void send(String destinatario, String mensaje) {
        NotificationLogger.INSTANCE.log(channel(), destinatario, mensaje);
    }
}

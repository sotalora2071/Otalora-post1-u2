package com.patrones.u2;

public interface Notifier {

    void send(String destinatario, String mensaje);

    String channel();
}

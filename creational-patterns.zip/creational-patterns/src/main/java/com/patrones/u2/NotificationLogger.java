/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.patrones.u2;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author sebastianotalora
 */
public enum NotificationLogger {

    INSTANCE ;

    private final List<String> logs = new ArrayList<>();
    private static final DateTimeFormatter formato
            = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    public void log(String canal, String destinatario, String mensaje) {
        String registro = "[" + LocalDateTime.now().format(formato) + "] "
                + "[" + canal + "] -> " + destinatario + ": " + mensaje;

        logs.add(registro);
        System.out.println(registro);
    }

    public void mostrarHistorial() {
        System.out.println("\n=== HISTORIAL ===");
        for (String log : logs) {
            System.out.println(log);
        }
        System.out.println("Total: " + logs.size());
    }

}

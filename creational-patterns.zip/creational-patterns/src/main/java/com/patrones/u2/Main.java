package com.patrones.u2;

public class Main {

    public static void main(String[] args) {

        System.out.println("=== DEMO PATRONES ===\n");

        // 🔹 Singleton
        NotificationLogger log1 = NotificationLogger.INSTANCE;
        NotificationLogger log2 = NotificationLogger.INSTANCE;

        System.out.println("¿Misma instancia?: " + (log1 == log2));

        // 🔹 Factory Method
        Notifier email = NotifierFactory.crear("email");
        Notifier sms = NotifierFactory.crear("sms");
        Notifier push = NotifierFactory.crear("push");

        email.send("cliente@mail.com", "Pedido confirmado");
        sms.send("+573000000000", "Tu pedido va en camino");
        push.send("device123", "Nuevo mensaje");

        // 🔹 Registrar nuevo tipo dinámicamente
        NotifierFactory.registrar("slack", () -> new Notifier() {
            public String channel() {
                return "SLACK";
            }

            public void send(String d, String m) {
                NotificationLogger.INSTANCE.log(channel(), d, m);
            }
        });

        Notifier slack = NotifierFactory.crear("slack");
        slack.send("#ventas", "Nuevo pedido recibido");

        // 🔹 Mostrar historial
        NotificationLogger.INSTANCE.mostrarHistorial();
    }
}
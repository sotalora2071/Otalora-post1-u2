package com.patrones.u2;

public class EmailNotifier implements Notifier {

    public String channel() {
        return "EMAIL";
    }

    public void send(String destinatario, String mensaje) {
        NotificationLogger.INSTANCE.log(channel(), destinatario, mensaje);
    }
}
